package com.mine.trpgbeta

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

class village: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}